TEBAK ANGKA - PHASE 6
======================

Project ini sudah siap diunggah ke layanan hosting statis.

File utama:
- index.html

CARA ONLINE PALING SEDERHANA
1. Buat akun hosting statis yang kamu pilih.
2. Buat project/site baru.
3. Upload file index.html.
4. Publish/deploy.
5. Buka alamat website yang diberikan hosting.
6. Tes game dari HP lain.

CATATAN
- Game saat ini berjalan sebagai website statis.
- Skor, nama, statistik, dan leaderboard pada versi ini tersimpan di browser/perangkat pemain.
- Leaderboard belum menjadi leaderboard global karena belum ada database/server.
- Slot iklan sudah disiapkan, tetapi iklan nyata harus dipasang setelah website online dan akun jaringan iklan memenuhi persyaratan.
- Jangan memasukkan password atau data pribadi ke file game.

TAHAP LANJUTAN
Phase 7 dapat menambahkan backend/database agar:
- akun pemain dapat dibuat,
- skor tersimpan secara online,
- leaderboard menjadi global,
- Daily Challenge dapat memakai data server,
- dan sistem monetisasi dapat dikelola lebih serius.
